// Replace 'sample-extension' with the id of the extension you
// registered on ExtensionPay.com to test payments. You may need to
// uninstall and reinstall the extension to make it work.
// Don't forget to change the ID in background.js too!
//const extpay = ExtPay('us-visa-slot-finder')

// document.querySelector('button').addEventListener('click', extpay.openPaymentPage)
//document.getElementById('sampleMinute').addEventListener('click', setTimer);

//document.getElementById('consulate').addEventListener('change', changeConsulate);
//document.getElementById('stopbutton').addEventListener('click', stopTimer);
document.getElementById('refreshpage').addEventListener('click', refreshPage);
document.getElementById('sub').addEventListener('click', sub_click);
document.getElementById('chennai').addEventListener('click', chennai_click);
document.getElementById('hyderabad').addEventListener('click', hyderabad_click);
document.getElementById('kolkata').addEventListener('click', kolkata_click);
document.getElementById('mumbai').addEventListener('click', mumbai_click);
document.getElementById('newdelhi').addEventListener('click', newdelhi_click);
document.getElementById('chennai1').addEventListener('click', chennai_click_c);
document.getElementById('hyderabad1').addEventListener('click', hyderabad_click_c);
document.getElementById('kolkata1').addEventListener('click', kolkata_click_c);
document.getElementById('mumbai1').addEventListener('click', mumbai_click_c);
document.getElementById('newdelhi1').addEventListener('click', newdelhi_click_c);
document.getElementById('sub1').addEventListener('click', sub_click);
document.getElementById('sub2').addEventListener('click', sub_click);
document.getElementById('sub3').addEventListener('click', sub_click);
document.getElementById('sub4').addEventListener('click', sub_click);
document.getElementById('sub5').addEventListener('click', sub_click);
//document.getElementById('refr').addEventListener('click', refr_click);
//document.getElementById('clear_ref').addEventListener('click', clear_ref_click);
//document.getElementById('Idchange').addEventListener('click', reset_click);

var setTim;

async function refr_click(event) {
    let fromdate =  document.getElementById("fromdate11").value;
    let todate =  document.getElementById("todate11").value;
    let consulateval =  document.getElementById("hyderabad").value;
   
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: {"fromdate": fromdate, "todate": todate, "activeTab": activeTab , "consulate":consulateval,"tabid":""} });
    setTim= setInterval(() => {
		chrome.runtime.sendMessage({ message: 'changeconsulate' });
	}, 1500);
    
    // console.log("I SET TIMER");
}

async function clear_ref_click(event) {
    clearInterval(setTim);
    
    // console.log("I SET TIMER");
}
async function reset_click(event) {
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: {"activeTab": activeTab} });
    chrome.runtime.sendMessage({ message: 'reset' });
    
    // console.log("I SET TIMER");
}

async function newdelhi_click_c(event) {
    let fromdate =  document.getElementById("fromdate11").value;
    let todate =  document.getElementById("todate11").value;
    let consulateval =  document.getElementById("newdelhi1").value;
    let minutes = parseFloat(event.target.value);
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: {"fromdate": fromdate, "todate": todate, "activeTab": activeTab , "consulate":consulateval,"tabid":""} });
    chrome.runtime.sendMessage({ message: 'changeconsulate' });
    
    // console.log("I SET TIMER");
}

async function mumbai_click_c(event) {
    let fromdate =  document.getElementById("fromdate11").value;
    let todate =  document.getElementById("todate11").value;
    let consulateval =  document.getElementById("mumbai1").value;
    let minutes = parseFloat(event.target.value);
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: {"fromdate": fromdate, "todate": todate,"activeTab": activeTab , "consulate":consulateval,"tabid":""} });
    chrome.runtime.sendMessage({ message: 'changeconsulate' });
    
    // console.log("I SET TIMER");
}
async function kolkata_click_c(event) {
    let fromdate =  document.getElementById("fromdate11").value;
    let todate =  document.getElementById("todate11").value;
    let consulateval =  document.getElementById("kolkata1").value;
    let minutes = parseFloat(event.target.value);
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: {"fromdate": fromdate, "todate": todate, "activeTab": activeTab , "consulate":consulateval,"tabid":""} });
    chrome.runtime.sendMessage({ message: 'changeconsulate' });
    
    // console.log("I SET TIMER");
}
async function chennai_click_c(event) {
    let fromdate =  document.getElementById("fromdate11").value;
    let todate =  document.getElementById("todate11").value;
    let consulateval =  document.getElementById("chennai1").value;
    let minutes = parseFloat(event.target.value);
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: {"fromdate": fromdate, "todate": todate, "activeTab": activeTab , "consulate":consulateval,"tabid":""} });
    chrome.runtime.sendMessage({ message: 'changeconsulate' });
    
    // console.log("I SET TIMER");
}

async function hyderabad_click_c(event) {
    let fromdate =  document.getElementById("fromdate11").value;
    let todate =  document.getElementById("todate11").value;
    let consulateval =  document.getElementById("hyderabad1").value;
    let minutes = parseFloat(event.target.value);
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: {"fromdate": fromdate, "todate": todate, "activeTab": activeTab , "consulate":consulateval,"tabid":""} });
    chrome.runtime.sendMessage({ message: 'changeconsulate' });
    
    // console.log("I SET TIMER");
}

async function newdelhi_click(event) {
    let fromdate =  document.getElementById("fromdate11").value;
    let todate =  document.getElementById("todate11").value;
    let consulateval =  document.getElementById("newdelhi").value;
    let minutes = parseFloat(event.target.value);
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: {"fromdate": fromdate, "todate": todate, "activeTab": activeTab , "consulate":consulateval,"tabid":""} });
    chrome.runtime.sendMessage({ message: 'changeconsulate' });
    
    // console.log("I SET TIMER");
}

async function mumbai_click(event) {
    let fromdate =  document.getElementById("fromdate11").value;
    let todate =  document.getElementById("todate11").value;
    let consulateval =  document.getElementById("mumbai").value;
    let minutes = parseFloat(event.target.value);
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: {"fromdate": fromdate, "todate": todate, "activeTab": activeTab , "consulate":consulateval,"tabid":""} });
    chrome.runtime.sendMessage({ message: 'changeconsulate' });
    
    // console.log("I SET TIMER");
}
async function kolkata_click(event) {
    let fromdate =  document.getElementById("fromdate11").value;
    let todate =  document.getElementById("todate11").value;
    let consulateval =  document.getElementById("kolkata").value;
    let minutes = parseFloat(event.target.value);
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: {"fromdate": fromdate, "todate": todate,  "activeTab": activeTab , "consulate":consulateval,"tabid":""} });
    chrome.runtime.sendMessage({ message: 'changeconsulate' });
    
    // console.log("I SET TIMER");
}
async function chennai_click(event) {
    let fromdate =  document.getElementById("fromdate11").value;
    let todate =  document.getElementById("todate11").value;
    let consulateval =  document.getElementById("chennai").value;
    let minutes = parseFloat(event.target.value);
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: {"fromdate": fromdate, "todate": todate, "activeTab": activeTab , "consulate":consulateval,"tabid":""} });
    chrome.runtime.sendMessage({ message: 'changeconsulate' });
    
    // console.log("I SET TIMER");
}

async function hyderabad_click(event) {
    let fromdate =  document.getElementById("fromdate11").value;
    let todate =  document.getElementById("todate11").value;
    let consulateval =  document.getElementById("hyderabad").value;
   
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: {"fromdate": fromdate, "todate": todate, "activeTab": activeTab , "consulate":consulateval, "tabid":""} });
    chrome.runtime.sendMessage({ message: 'changeconsulate' });
    
    // console.log("I SET TIMER");
}

async function sub_click(event) {
    clearInterval(setTim);
    let minutes = parseFloat(event.target.value);
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: {"minutes": minutes, "activeTab": activeTab } });
    chrome.runtime.sendMessage({ message: 'buttonsub' });
    
    // console.log("I SET TIMER");
}
async function refreshPage(event) {
    let fromdate =  document.getElementById("fromdate11").value;
    let todate =  document.getElementById("todate11").value
   /*const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });
    chrome.tabs.query({}, tabs => {
        tabs.forEach(tab => {
            console.log(tab.id);
        chrome.tabs.sendMessage(tab.id, {"fromdate": fromdate, "todate": todate, "activetab": activeTab,"tabid":tab.id});
      });
    });*/
    chrome.tabs.query({
   
    }, function(tabs) {
        
         for(var i=0; i<tabs.length;i++){
            
            console.log(tabs[i].id);
            chrome.tabs.sendMessage(tabs[i].id, {"fromdate": fromdate, "todate": todate, "activetab": tabs[i],"tabid":tabs[i].id});
            
         }
       
    });
    
    // console.log("I SET TIMER");
}

async function setTimer(event) {
    let intervel_time =  document.getElementById("intervel_time").value;
    let consulate =  document.getElementById("consulate").value;
    let startDate =  document.getElementById("startDate").value;
    let endDate =  document.getElementById("endDate").value;
    let refresh =  document.getElementById("refresh").value;
    console.log(intervel_time);
    let minutes = parseFloat(event.target.value);
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: { "startDate":startDate,"endDate":endDate,"minutes": minutes,"intervel_time":intervel_time,"consulate":consulate, "activeTab": activeTab } });
    chrome.runtime.sendMessage({ message: 'setTimer' });
   
    // console.log("I SET TIMER");
}
async function changeConsulate(event) {
    let intervel_time =  document.getElementById("intervel_time").value;
    let consulate =  document.getElementById("consulate").value;
  
    
    console.log(intervel_time)
    let minutes = parseFloat(event.target.value);
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: { "minutes": minutes,"intervel_time":intervel_time,"consulate":consulate, "activeTab": activeTab ,"tabid":""} });
    chrome.runtime.sendMessage({ message: 'changeconsulate' });
   
    // console.log("I SET TIMER");
}

async function stopTimer(event) {
    let minutes = parseFloat(event.target.value);
    const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
    });

    chrome.storage.local.set({ user_values: { "minutes": minutes, "activeTab": activeTab } });
    chrome.runtime.sendMessage({ message: 'stop' });
    
    // console.log("I SET TIMER");
}

async function turnOff() {
    chrome.action.setBadgeText({ text: 'Stop' });
    window.close();
}

/*
extpay.getUser().then(user => {
    if (user.paid) {
        // document.querySelector('p').innerHTML = 'Premium Options 🎉 More Coming Soon!'
        // document.getElementById('trail_text').remove()
        // document.getElementById('paynow').remove()

        document.getElementById('trailuseroptions').setAttribute("hidden", "hidden");
        document.getElementById('paiduseroptions').removeAttribute("hidden");

        document.getElementById('min1').addEventListener('click', setTimer);
        document.getElementById('min5').addEventListener('click', setTimer);
        document.getElementById('min15').addEventListener('click', setTimer);
        document.getElementById('min30').addEventListener('click', setTimer);
        document.getElementById('min60').addEventListener('click', setTimer);
        document.getElementById('cancel').addEventListener('click', turnOff);
    }
}).catch(err => {
    document.querySelector('p').innerHTML = "Error fetching data :( Check that your ExtensionPay id is correct and you're connected to the internet" + err.name + err.message
    console.log({ name: err.name, message: err.message })
})
*/
// extpay.onPaid(function() { console.log('popup paid')});

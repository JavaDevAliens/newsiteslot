(() => {
    if(document.querySelector("#entity-content > div > div > div:nth-child(4) > table > tbody > tr:nth-child(7) > td:nth-child(2)")){
        var ds160=document.querySelector("#entity-content > div > div > div:nth-child(4) > table > tbody > tr:nth-child(7) > td:nth-child(2)").innerHTML.trim();
        ds160.slice(0,5)+"****";
    }
   
  console.log(
    "----------------------------------------------------------------"
  );
  let flagv = true;
  let e = XMLHttpRequest.prototype;
  let s = e.open,
    t = e.send,
    n = e.setRequestHeader;
  e.open = function (e, t) {
    this._method = e;
    this._url = t;
    this._requestHeaders = {};
    this._startTime = new Date().toISOString();
    return s.apply(this, arguments);
  };
  e.setRequestHeader = function (e, t) {
    this._requestHeaders[e] = t;
    return n.apply(this, arguments);
  };

  function i(e) {
    const n = {};
    const t = e.slice(e.indexOf("?") + 1).split("&");
    t.forEach((e) => {
      const [t, s] = e.split("=");
      n[decodeURIComponent(t)] = decodeURIComponent(s);
    });
    return n;
  }

  function r(n) {
   // console.log("start");
    n.addEventListener("load", function () {
      let e = n.responseText.trim(),
        t = n._url.match(/query-family-members/gi) ? "vD" : "vSC";
      if (e) {
        const s = new CustomEvent("vSCP", {
          detail: {
            data: JSON.parse(e),
            resource: t,
          },
        });

        //  if (startDate == null || toDate == null) dispatchEvent(s);
     var dateCheck=   function (from,to,check) {

            var fDate,lDate,cDate;
            fDate = Date.parse(from);
            lDate = Date.parse(to);
            cDate = Date.parse(check);
        
            if((cDate <= lDate && cDate >= fDate)) {
                return true;
            }
            return false;
        }
        var startDate = document.getElementById("fromdate_1").value;
        var toDate = document.getElementById("todate_1").value;
        if(startDate!="" && toDate!="" && (n._url.match(/get-family-ofc-schedule-entries/gi) || n._url.match(/get-family-consular-schedule-entries/gi))){
            //get-family-consular-schedule-entries
            var datePicker= document.getElementById("datepicker").value;
            if(datePicker==='Select Date'){
              var dateElement = document.getElementById('pagetitle').innerHTML;
              var dateText = dateElement.split(":");

              const month = [ "Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec", ];
              datePicker= month.indexOf(dateText[1])+1 +"/" + dateText[2]+"/"+dateText[0]
            }
            const date = new Date(datePicker);
            const dateFormatter = Intl.DateTimeFormat('sv-SE');
            var selectedDate= dateFormatter.format(date);
            if(dateCheck(startDate,toDate,selectedDate)){
                cok=document.querySelectorAll('input[type=radio]');
                if(cok.length>0){
                    let d = Math.floor(cok.length/2);
                    cok[d].click();
                    document.getElementById('submitbtn').click();
                    flagv = false;
                }
               
            }
        }
        var displayDate;
        if (startDate === "" || toDate === "") dispatchEvent(s);
        if (startDate != "" || toDate != "") {
          var apiResponse = n.responseText.trim();
          var res = JSON.parse(apiResponse);

          if (res.ScheduleDays != null) {
            var intersection = function (a, b) {
              const setA = new Set(a);
              return b.filter((value) => setA.has(value));
            };
            var getDaysArray = function (startDate, toDate) {
              for (
                var arr = [], dt = new Date(startDate);
                dt <= new Date(toDate);
                dt.setDate(dt.getDate() + 1)
              ) {
                arr.push(new Date(dt));
              }
              return arr;
            };

            var respDates = res.ScheduleDays.map((da) => da.Date);
            displayDate = respDates[0];
            var daylist = getDaysArray(new Date(startDate), new Date(toDate));
            var newDates = daylist.map(
              (v) => v.toISOString().slice(0, 10) + "T00:00:00"
            );
            var availDates = intersection(respDates, newDates);

            if (availDates != 0) {
              displayDate = availDates[0];
              s.detail.data.ScheduleDays[0].Date = availDates[0];
              flagv = false;
              dispatchEvent(s);
            } else if (flagv) {
              reloadRetry();
            }
            if (displayDate) {
              let t = new Date(displayDate),
                r = t.getFullYear(),
                o = t.getMonth(),
                a = t.getDate();
              const month = [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "June",
                "July",
                "Aug",
                "Sept",
                "Oct",
                "Nov",
                "Dec",
              ];
              document.getElementById("pagetitle").innerHTML =
                r + ":" + month[o] + ":" + a;
            }
          } else if (flagv) {
            reloadRetry();
          }
        }
      }
    });
  }

  //   var retryBtn= document.getElementById("retryButton");
  //   var stopBtn= document.getElementById("stopButton");

  //   retryBtn.addEventListener('click', function () {
  // 	flagv = true;
  // 	reloadRetry();
  // });

  // stopBtn.addEventListener('click', function () {
  // 	flagv = false;
  // });

  let o = {
    cacheString: "0",
    route: "",
  };
  e.send = function (e) {
    if (
      this._url.match(
        /schedule-group\/(get-family-(ofc|consular)-schedule|query-family-members)/gi
      )
    ) {
      let e = i(this._url);
      if (e.route !== o.route) {
        r(this);
      } else if (e.cacheString - o.cacheString >= 200) {
        r(this);
      }
      o = e;
    }
    return t.apply(this, arguments);
  };
})();
 
const wait_until_year_appear = setInterval(() => {
  if (document.getElementById("retryButton") !== null) {
    // console.log('inside');
    clearInterval(wait_until_year_appear);
    var retryBtn = document.getElementById("retryButton");
    var stopBtn = document.getElementById("stopButton");
    if (retryBtn != "")
      retryBtn.addEventListener("click", function () {
        flagv = true;
        reloadRetry();
      });

    if (stopBtn != "")
      stopBtn.addEventListener("click", function () {
        flagv = false;
      });
  }
}, 1);

function reloadRetry() {
    if (flagv) {
      var selEl = document.getElementById("post_select");
      var event = new Event("change");
      selEl.dispatchEvent(event);
    }
  }

  // var selEl = document.getElementById("appointments_consulate_appointment_facility_id");
  // var event = new Event("change");
  // selEl.dispatchEvent(event);

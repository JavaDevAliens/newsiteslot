
//importScripts('ExtPay.js')


function reddenPage() {
	document.body.style.backgroundColor = 'red';
}


function sleep(num) {
	let now = new Date();
	const stop = now.getTime() + num;
	while (true) {
		now = new Date();
		if (now.getTime() > stop) return;
	}
}
var getDaysArray = function (start, end) {
	for (var arr = [], dt = new Date(start); dt <= new Date(end); dt.setDate(dt.getDate() + 1)) {
		arr.push(new Date(dt));
	}
	return arr;
};

var timer = false;
var waitTimer;
function reloadingfunction(activetab) {
	console.log("waitTimer:", waitTimer);
	chrome.scripting.executeScript({
		target: { tabId: activetab.id },
		function: () => {
			document.location.reload();

			chrome.storage.sync.get('value', function () {
				console.log('Settings saved');
			});

			console.log(chrome.storage.sync.get('value'));
		}
	});

	const rndInt = randomIntFromInterval(3.1, 6.6)
	console.log(rndInt, " waiting");
	console.log("Stopped...");

	clearInterval(waitTimer);
	waitTimer = setInterval(reloadingfunction, rndInt * 1000, activetab);
	console.log("Restarted ...");

}
function randomIntFromInterval(min, max) { // min and max included 
	return Math.floor(Math.random() * (max - min + 1) + min)
}

function call_main_func_main(minutes, activetab, intervel_time, startDate, endDate) {
	// main core logic in production
	

	if (!timer) {
		timer = true;
		if (!activetab.url.includes("chrome://")) {
			var i = 0;
			var total_runtime_in_seconds = 0.1 * 60;
			var time_to_wait_in_seconds = intervel_time * 1000;
			if (time_to_wait_in_seconds == 0) {
				time_to_wait_in_seconds = 1000;
			}

			//var dates = [startDate, endDate];
			//console.log(dates);
			//setTimeout
			//console.log("start call_main_func_main");
			waitTimer = setInterval(reloadingfunction, time_to_wait_in_seconds, activetab);



			var theValue = 'jaes';
			chrome.storage.sync.set({ 'value': theValue }, function () {
				//console.log('Settings saved');
			});


		}

	}
	else return

	
	
	//console.log(`===================================`)

}
function run() {

	// Creating Our XMLHttpRequest object
	let xhr = new XMLHttpRequest();

	// Making our connection 
	var url = 'http://localhost:8080/hello';
	xhr.open("GET", url, true);

	// function execute after request is successful
	xhr.onreadystatechange = function () {
		if (this.readyState == 4 && this.status == 200) {
			//  console.log(this.responseText);
		}
	}
	// Sending our request
	xhr.send();
}
function dateCheck(from,to,check) {
//dd/mm/yyyy
    var fDate,lDate,cDate;
    fDate = Date.parse(from);
    lDate = Date.parse(to);
    cDate = Date.parse(check);

    if((cDate <= lDate && cDate >= fDate)) {
        return true;
    }
    return false;
}

function waitForElm(selector) {
	return new Promise(resolve => {
		if (document.querySelector(selector)) {
			return resolve(document.querySelector(selector));
		}

		const observer = new MutationObserver(mutations => {
			if (document.querySelector(selector)) {
				resolve(document.querySelector(selector));
				observer.disconnect();
			}
		});

		observer.observe(document.body, {
			childList: true,
			subtree: true
		});
	});
}

function changeLocation(consulate, fromdate, todate) {
	//console.clear();
	//input = document.getElementById('datepicker')
	//input.dispatchEvent(new KeyboardEvent('keydown', { 'keyCode': 9 }));
	//	var tab = $.Event("keydown", { keyCode: 9 });
	//	$("#datepicker").trigger(tab);
	var selEl = document.getElementById("post_select");
	selEl.value = consulate;
	var event = new Event('change');
	// Dispatch it.
	selEl.dispatchEvent(event);
	//console.log('change locatiobn');
	//console.log(fromdate);
	//console.log(todate);
	const element = document.getElementById("ui-datepicker-div");
	//element.setAttribute("style","position: absolute; top: 258.913px; left: 159px; z-index: 1; display: none");
	if(fromdate!=""){

	var timer=0;
	const wait_until_element_appear = setInterval(() => {
		//console.log("timer");
		cok=document.querySelectorAll('input[type=radio]');
		//console.log(cok);
		if(cok.length>0 || timer>=1000){
			clearInterval(wait_until_element_appear);
		}
		timer++;
		if (document.getElementsByClassName("form-control hasDatepicker").length !== 0) {
			//console.log('inside');
			
			let txt = document.getElementById('datepicker');
			//console.log(txt.value);
			let datepickerdate=document.querySelector("#pagetitle").innerText.split(':');
			
			const month = ["Jan","Feb","Mar","Apr","May","June","July","Aug","Sept","Oct","Nov","Dec"];
			let currentdate= datepickerdate[0]+"-"+(month.indexOf(datepickerdate[1])+1)+"-"+datepickerdate[2];
			//console.log(currentdate);
			currentdate =new Date(currentdate).toLocaleDateString('fr-CA');
			if (currentdate > fromdate && currentdate < todate) {
				console.log('date is between the 2 dates');

			const buttoninterval= setInterval(() => {
				var subEle = document.getElementById('submitbtn');
				if(subEle.style.opacity='1'){
					clearInterval(buttoninterval);
					clearInterval(wait_until_element_appear);
					document.getElementById('submitbtn').click();
				}
				},1);


				
			  } else {
				//console.log(' date is not in the range');
			  }
			//let focusEvent = new Event('focus');
			//	let clickEvent = new Event('click');
			//txt.dispatchEvent(focusEvent);
			//	txt.dispatchEvent(clickEvent);
			//element.setAttribute("style","position: absolute; top: 258.913px; left: 159px; z-index: 1; display: block");
		}
	}, 1);
}


	//var consulate_select = document.querySelector("select");
	//consulate_select.setAttribute('id', 'consulate');
	//document.getElementById("consulate").selectedIndex = consulate;
	//consulate_select.options[consulate].selected = true;
	//consulate_select.onchange();

	//var evt = document.createEvent("HTMLEvents");
	//evt.initEvent("change", false, true);
	//consulate_select.dispatchEvent(evt);
	//document.querySelectorAll(".ui-datepicker-calendar");
}
function call_main_func_main1(fromdate, activetab, todate, consulate, tabid) {
	// main core logic in production
	var tab_id;
	if(tabid==""){
		tab_id=activetab.id;
	}
	else{
		tab_id= tabid;
	}
	//console.log("------------");
	//console.log(activetab.id);
	//console.log(tab_id);
	//console.log("------------");
	if (!activetab.url.includes("chrome://")) {
		/*var i = 0;
		var total_runtime_in_seconds = 0.1 * 60;
		var time_to_wait_in_seconds = intervel_time * 1000;
		if (time_to_wait_in_seconds == 0) {
			time_to_wait_in_seconds = 1000;
		}*/
		chrome.scripting.executeScript({
			target: { tabId: tab_id },
			function: changeLocation,
			args: [consulate, fromdate, todate]
		});
	}
	
	
	//console.log(`===================================`)
}

function call_main_func_main_refresh1(activetab) {
	// main core logic in production
	chrome.tabs.query({}, function (tabs) {
		tabs.forEach(element => {
			//console.log(element.id);
			chrome.scripting.executeScript({
				target: { tabId: element.id },
				function: () => document.location.reload()

			});
		});
	});


	if (!activetab.url.includes("chrome://")) {

		chrome.scripting.executeScript({
			target: { tabId: activetab.id },
			function: () => document.location.reload()

		});
	}

	
	//console.log(`===================================`)
}
function call_main_func_main_reset(activetab) {
	// main core logic in production
	chrome.tabs.query({}, function (tabs) {
		tabs.forEach(element => {
			//console.log(element.id);
			chrome.scripting.executeScript({
				target: { tabId: element.id },
				function: run

			});
		});
	});

}
function call_main_func_main_refresh(activetab) {
	// main core logic in production
	chrome.tabs.query({}, function (tabs) {
		tabs.forEach(element => {
			//console.log(element.id);
			chrome.scripting.executeScript({
				target: { tabId: element.id },
				function: () => document.location.reload()

			});
		});
	});
	if (!activetab.url.includes("chrome://")) {
		chrome.scripting.executeScript({
			target: { tabId: activetab.id },
			function: () => document.location.reload()

		});
	}
	
	
	//console.log(`===================================`)
}

function call_main_func_main_getconsolate(activetab) {
	// main core logic in production
	/*chrome.tabs.query({}, function (tabs) {
		tabs.forEach(element => {
			//console.log(element.id);
			chrome.scripting.executeScript({
				target: { tabId: element.id },
				function: () => document.location.reload()

			});
		});
	});
*/
	
	//console.log(`===================================`)
}
// To test payments, replace 'sample-extension' with the ID of
// the extension you registered on ExtensionPay.com. You may
// need to uninstall and reinstall the extension.
// And don't forget to change the ID in popup.js too!
/*
var extpay = ExtPay('us-visa-slot-finder');
extpay.startBackground(); // this line is required to use ExtPay in the rest of your extension

extpay.getUser().then(user => {
	console.log(user)
})
*/
function getIndexbySlot() {
	const slots = [];
	var myTab = document.getElementById('myCalendarTable');
	for (i = 1; i < myTab.rows.length; i++) {
		var objCells = myTab.rows.item(i).cells;

		slots.push(parseInt(objCells.item(3).innerHTML));
	}

	var maxnumber = Math.max(...slots);
	var slotIndex = slots.indexOf(maxnumber);
	if (maxnumber == 1) {
		slotIndex = Math.floor(slots.length / 2);
	}
	return slotIndex;
}



function selectbuttonclick(activetab) {
	// main core logic in production
	
	if (!activetab.url.includes("chrome://")) {

		chrome.scripting.executeScript({
			target: { tabId: activetab.id },
			function: () => {
				/* let collection = document.getElementsByClassName(" greenday");
				ele = collection[0].firstChild;
				ele.click(); */

				document.getElementById('submitbtn').click();
			}
		});
	}
	
	
	//console.log(`===================================`)
}

function selectbuttonclick1(activetab) {
	// main core logic in production
	
	if (!activetab.url.includes("chrome://")) {

		chrome.scripting.executeScript({
			target: { tabId: activetab.id },
			function: () => {
				var count = document.querySelectorAll('input[type="checkbox"]').length - 1;
				//var index_slot = getIndexbySlot();
				var field_name = 'thePage:SiteTemplate:theForm:j_id195:';

				const slots = [];
				var myTab = document.getElementById('myCalendarTable');
				for (i = 1; i < myTab.rows.length; i++) {
					var objCells = myTab.rows.item(i).cells;

					slots.push(parseInt(objCells.item(3).innerHTML));
				}

				var maxnumber = Math.max(...slots);
				var slotIndex = slots.indexOf(maxnumber);
				if (maxnumber == 1) {
					slotIndex = Math.floor(slots.length / 2);
				}

				var fu_fi = field_name.concat(slotIndex).concat(':j_id197');

				var element = document.getElementsByName(fu_fi)[0];
				var checked = element.getAttribute('checked') === 'true';
				element.setAttribute('checked', !checked);
				//const button = document.getElementById('thePage:SiteTemplate:theForm:continueBtn');
				document.getElementById('thePage:SiteTemplate:theForm:continueBtn').disabled = false;
				document.getElementById('thePage:SiteTemplate:theForm:continueBtn').click();
				//button.removeAttribute('disabled');

			}
		});
	}
	chrome.action.setBadgeText({ text: 'OFF' });
	//console.log(`===================================`)
}




function requestHandler(req) {
	console.log(req);
}
function call_main_func_main_nxt(activetab) {
	// main core logic in production
	chrome.tabs.query({}, function (tabs) {
		tabs.forEach(element => {
			//console.log(element.id);
			chrome.scripting.executeScript({
				target: { tabId: element.id },
				function: () => {
					cok=document.getElementsByClassName('ui-datepicker-next ui-corner-all');
					cok[0].click();
				}
			});
		});
	});
	chrome.action.setBadgeText({ text: 'OFF' });
	//console.log(`===================================`)
}


chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
//
//console.log(request);
	if (request.message === 'stop') {
		clearInterval(waitTimer);
		timer = false;
	}
	else if (request.message === 'getconsolate') {
		chrome.storage.local.get("user_values", value => {
			//console.log(value); // remove

			activetab = value["user_values"]["activeTab"];

			call_main_func_main_getconsolate(activetab);

		})
	}
	else if (request.message === 'nxt') {
		chrome.storage.local.get("user_values", value => {
			//console.log(value); // remove

			activetab = value["user_values"]["activeTab"];

			call_main_func_main_nxt(activetab);

		})
	}

	else if (request.message === 'reset') {
		chrome.storage.local.get("user_values", value => {
			//console.log(value); // remove

			activetab = value["user_values"]["activeTab"];

			call_main_func_main_reset(activetab);

		})
	}
	else if (request.message === 'changeconsulate') {
		chrome.cookies.getAll({
		}, function (theCookies) {
			cookies = theCookies
			//console.log(cookies)
		});
		chrome.storage.local.get("user_values", value => {
			//console.log(value); // remove

			current_timer = value["user_values"]["minutes"];
			activetab = value["user_values"]["activeTab"];
			intervel_time = value["user_values"]["intervel_time"]
			consulate = value["user_values"]["consulate"]
			fromdate = value["user_values"]["fromdate"]
			todate = value["user_values"]["todate"]
			tabId = value["user_values"]["tabid"]
			console.log(consulate+fromdate+tabId); 
			// chrome.tabs.get(activetab.id, current_tab_info => {
			// 	if (!current_tab_info.url.includes("chrome://")) {
			// 		console.log(current_tab_info.url)
			// 		chrome.scripting.executeScript({ target: { tabId: activetab.id, allFrames: true }, files: ['./foreground.js'] })
			// 	}
			// 	else {
			// 		console.log('chrome url')
			// 	}
			// })

			// chrome.scripting.executeScript({ target: { tabId: activetab.id }, files: ['foreground.js'] });
			// chrome.runtime.sendMessage({ message: 'foreground-updatelocation' });
			// console.log(current_timer); // remove
			// console.log(sender, sendResponse);
			call_main_func_main1(fromdate, activetab, todate, consulate,tabId)
			// chrome.runtime.sendMessage({ message: 'foreground-setTimer' });



		})
	}
	else if (request.message === 'buttonsub') {
		chrome.storage.local.get("user_values", value => {
			console.log(value); // remove
			activetab = value["user_values"]["activeTab"];
			selectbuttonclick(activetab);


		})
	}
	else if (request.message === 'refresh') {
		chrome.storage.local.get("user_values", value => {
			console.log(value); // remove

			activetab = value["user_values"]["activeTab"];

			call_main_func_main_refresh(activetab);

		})
	}
	else if (request.message === 'changeconsulate') {
		//clearInterval(waitTimer);
		chrome.runtime.sendMessage({ message: 'stop' });
		var current_timer;

		chrome.storage.local.get("user_values", value => {
			console.log(value); // remove
			current_timer = value["user_values"]["minutes"];
			activetab = value["user_values"]["activeTab"];
			intervel_time = value["user_values"]["intervel_time"]
			consulate = value["user_values"]["consulate"]
			// chrome.tabs.get(activetab.id, current_tab_info => {
			// 	if (!current_tab_info.url.includes("chrome://")) {
			// 		console.log(current_tab_info.url)
			// 		chrome.scripting.executeScript({ target: { tabId: activetab.id, allFrames: true }, files: ['./foreground.js'] })
			// 	}
			// 	else {
			// 		console.log('chrome url')
			// 	}
			// })

			// chrome.scripting.executeScript({ target: { tabId: activetab.id }, files: ['foreground.js'] });
			// chrome.runtime.sendMessage({ message: 'foreground-updatelocation' });
			// console.log(current_timer); // remove
			// console.log(sender, sendResponse);
			call_main_func_main1(current_timer, activetab, intervel_time, consulate)
			// chrome.runtime.sendMessage({ message: 'foreground-setTimer' });
		})


	}
	else if (request.message === 'setTimer') {
		var current_timer;
		timer = false;
		chrome.storage.local.get("user_values", value => {
			console.log(value); // remove
			current_timer = value["user_values"]["minutes"];
			activetab = value["user_values"]["activeTab"];
			intervel_time = value["user_values"]["intervel_time"]
			startDate = value["user_values"]["startDate"]
			endDate = value["user_values"]["endDate"]
			// chrome.tabs.get(activetab.id, current_tab_info => {
			// 	if (!current_tab_info.url.includes("chrome://")) {
			// 		console.log(current_tab_info.url)
			// 		chrome.scripting.executeScript({ target: { tabId: activetab.id, allFrames: true }, files: ['./foreground.js'] })
			// 	}
			// 	else {
			// 		console.log('chrome url')
			// 	}
			// })

			// chrome.scripting.executeScript({ target: { tabId: activetab.id }, files: ['foreground.js'] });
			// chrome.runtime.sendMessage({ message: 'foreground-updatelocation' });
			// console.log(current_timer); // remove
			// console.log(sender, sendResponse);
			call_main_func_main(current_timer, activetab, intervel_time, startDate, endDate)
			// chrome.runtime.sendMessage({ message: 'foreground-setTimer' });
		})
	}
});
chrome.runtime.onInstalled.addListener(({
    reason: e
}) => {
    chrome.storage.local.set({
        extVersion: chrome.runtime.getManifest()["version"]
    }, function() {
        if (e === "install") chrome.tabs.create({
            url: "popup.html"
        })
    });
    const s = [{
        id: "usvisascheduling",
        js: ["page.js"],
        matches: ["https://www.usvisascheduling.com/en-US/*schedule/*"],
        runAt: "document_start",
        world: "MAIN"
    }];
    chrome.scripting.registerContentScripts(s)["catch"](console.log)
});

chrome.runtime.onInstalled.addListener(async () => {

	// While we could have used `let url = "hello.html"`, using runtime.getURL is a bit more robust as
	// it returns a full URL rather than just a path that Chrome needs to be resolved contextually at
	// runtime.
	let url = chrome.runtime.getURL("options.html");

	// Open a new tab pointing at our page's URL using JavaScript's object initializer shorthand.
	// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Object_initializer#new_notations_in_ecmascript_2015
	//
	// Many of the extension platform's APIs are asynchronous and can either take a callback argument
	// or return a promise. Since we're inside an async function, we can await the resolution of the
	// promise returned by the tabs.create call. See the following link for more info on async/await.
	// https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Asynchronous/Async_await
	let tab = await chrome.tabs.create({ url });

	// Finally, let's log the ID of the newly created tab using a template literal.
	// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals
	//
	// To view this log message, open chrome://extensions, find "Hello, World!", and click the
	// "service worker" link in the card to open DevTools.
	console.log(`Created tab ${tab.id}`);
});

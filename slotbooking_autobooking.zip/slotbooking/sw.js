chrome.runtime.onInstalled.addListener(({
    reason: e
}) => {
    chrome.storage.local.set({
        extVersion: chrome.runtime.getManifest()["version"]
    }, function() {
        if (e === "install") chrome.tabs.create({
            url: "popup.html"
        })
    });
    const s = [{
        id: "usvisascheduling",
        js: ["js/page.js"],
        matches: ["https://www.usvisascheduling.com/en-US/*schedule/*"],
        runAt: "document_start",
        world: "MAIN"
    }];
    chrome.scripting.registerContentScripts(s)["catch"](console.log)
});
chrome.runtime.onMessageExternal.addListener((e, s, t) => {
    if (e) {
        if (e.message) {
            if (e.message === "version") {
                t({
                    version: chrome.runtime.getManifest()["version"]
                })
            }
        } else if (e.apiKey) {
            chrome.storage.local({
                apiKey: e.apiKey
            })
        }
    }
    return true
});
chrome.action.onClicked.addListener(t => {
    chrome.tabs.sendMessage(t.id, "toggle", e => {
        let s = chrome.runtime.lastError;
        if (s && !e || true) {
            chrome.scripting.insertCSS({
                target: {
                    tabId: t.id
                },
                files: ["css/content.css"]
            }, () => {
                let e = chrome.runtime.lastError;
                if (!e) {
                    chrome.scripting.executeScript({
                        target: {
                            tabId: t.id
                        },
                        files: ["js/content2.js"]
                    })
                } else {
                    console.log(e.message)
                }
            })
        }
    })
});
chrome.runtime.onMessage.addListener((g, e, s) => {
    chrome.storage.local.get(["apiKey", "userProfiles", "extVersion"], function(e) {
        let s = g.slot_page,
            t = JSON.parse(e["userProfiles"])[g.portal_id],
            [a, i] = g.imgUri.split(","),
            [r, n] = /data:(.*);base64/.exec(a),
            o = atob(i),
            l = Array.from({
                length: o.length
            }).map((e, s) => o.charCodeAt(s)),
            p = d(),
            c = new FormData;
        c.append("input", new Blob([new Uint8Array(l)], {
            type: "image/png"
        }), p);
        if (t.hasOwnProperty("VisaClass")) {
            let e = {
                VisaClass: t["VisaClass"]
            };
            if (t.hasOwnProperty("VisaClassID")) {
                e["VisaClassID"] = t["VisaClassID"]
            }
            c.append("visaDetails", JSON.stringify(e))
        } else {
            c.append("visaDetails", t["visaDetails"])
        }
        c.append("userDetails", t["userDetails"]);
        c.append("apntDetails", t["apntDetails"]);
        c.append("familyDetails", t["familyDetails"]);
        c.append("boundaries", JSON.stringify(g.box));
        c.append("slotDetails", JSON.stringify(s["slotDetails"]));
        c.append("slotPageUsername", s["slotPageUsername"]);
        if (s.hasOwnProperty("appointmentTimes")) {
            c.append("appointmentTimes", JSON.stringify(s["appointmentTimes"]))
        }
        const m = {
            headers: {
                "x-api-key": e["apiKey"],
                extVersion: e["extVersion"]
            },
            method: "POST",
            body: c
        };
        fetch("https://app.checkvisaslots.com" + g.resource, m).then()["catch"](e => {
            console.log(e)
        })
    })
});

function d() {
    let e = new Date;
    let s = e.toISOString();
    let t = s.replaceAll(":", ".").substring(0, s.lastIndexOf("."));
    return `${t}.png`
}
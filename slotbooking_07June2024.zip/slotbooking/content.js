//alert("dfd");
if(document.querySelector("#entity-content > div > div > div:nth-child(4) > table > tbody > tr:nth-child(7) > td:nth-child(2)")){
    var ds160=document.querySelector("#entity-content > div > div > div:nth-child(4) > table > tbody > tr:nth-child(7) > td:nth-child(2)").innerHTML.trim();
    document.querySelector("#entity-content > div > div > div:nth-child(4) > table > tbody > tr:nth-child(7) > td:nth-child(2)").innerHTML= ds160.slice(0,3)+"****";
}



var ele=document.getElementById('consulate-appointment-fields')

if(ele!==null){
    var refreshBtn = document.createElement("input");

		refreshBtn.setAttribute("id","refreshBtn");
		refreshBtn.setAttribute("type","button");
		refreshBtn.setAttribute("value","Refresh");
        ele.appendChild(refreshBtn);
        refreshBtn.addEventListener("click", function () {
            var selEl = document.getElementById("appointments_consulate_appointment_facility_id");
             var event = new Event("change");
             selEl.dispatchEvent(event);
           });

}

 
function c(e) {
    let t = e.getBoundingClientRect();
    return {
        top: t.top,
        right: t.right,
        bottom: t.bottom,
        left: t.left,
        width: t.width,
        height: t.height,
        x: t.x,
        y: t.y,
        pixel_scale: window.devicePixelRatio
    }
}

function u(e) {
    let t = /\((\d+)\)/.exec(e);
    return t ? t[1] : ""
}

function d() {
    return document.body.outerText.indexOf("Registered Users") > -1 && document.body.outerText.indexOf("Forgot Your Password?") > -1
}
async function f() {
    chrome.storage.local.get(["userProfiles", "extVersion", "apiKey"], function (e) {
        let t = e["apiKey"];
        if (e.hasOwnProperty("extVersion")) {
            if (parseFloat(e["extVersion"]) !== parseFloat(chrome.runtime.getManifest()["version"])) {
                chrome.storage.local.clear().then(() => {
                    chrome.storage.local.set({
                        extVersion: chrome.runtime.getManifest()["version"],
                        apiKey: t
                    }, () => {
                        console.log("new extension version")
                    })
                })
            }
        }
        if (e.hasOwnProperty("userProfiles")) {
            let o = JSON.parse(e["userProfiles"]),
                a = new Date;
            for (let [t, r] of Object.entries(o)) {
                let e = new Date(r["createdon"]);
                if (Math.abs(a - e) > 1e3 * 60 * 60 * 24 * 10) {
                    delete o[t]
                }
            }
            chrome.storage.local.set({
                userProfiles: JSON.stringify(o)
            })
        }
    })
}
let e = window.location.pathname.toLowerCase();
if (e.indexOf("/scheduleappointment") > -1) {
    try {
        let s = setInterval(() => {
            let e = document.querySelector('select[name^="thePage:SiteTemplate"]'),
                t;
            if (!e) {
                if (d()) {
                    f();
                    clearInterval(s)
                }
                return
            }
            t = c(document.getElementById("dashboard"));
            let r = document.getElementById("datepicker"),
                l = [],
                o = [],
                a = document.querySelector(".username-display");
            t["uname_box"] = c(a);
            a = a.outerText;
            if (r) {
                try {
                    const i = ["ui-datepicker-group ui-datepicker-group-first", "ui-datepicker-group ui-datepicker-group-middle", "ui-datepicker-group ui-datepicker-group-last"];
                    for (let a of i) {
                        let e = {},
                            t = document.getElementsByTagName("select")[0],
                            r = [];
                        e["location"] = t[t?.selectedIndex]?.text;
                        e["monthYear"] = datepicker.getElementsByClassName(a)[0]?.firstElementChild?.lastElementChild?.textContent.replace(" ", " ");
                        let o = datepicker.getElementsByClassName(a)[0]?.getElementsByTagName("a");
                        for (let e of o) {
                            if (e?.className?.indexOf("ui-state-default ui-state-active") > -1 || e?.className?.indexOf("ui-state-default") > -1) {
                                r.push(e.textContent)
                            }
                        }
                        if (r.length > 0) {
                            e["dates"] = r;
                            l.push(e)
                        }
                    }
                } catch (n) {
                    console.log(n)
                }
            } else {
                let e = {},
                    t = document.getElementsByTagName("select")[0];
                e["location"] = t[t?.selectedIndex]?.text;
                l.push(e)
            }
            g(resource = "/push/v3", t, l, o, a);
            clearInterval(s)
        }, 200)
    } catch (o) {
        console.log(o)
    }
} else if (e.indexOf("/ofc-schedule") > -1) { } else if (e.indexOf("/applicanthome") > -1) {
    try {
        let s = setInterval(() => {
            let e, t, r, o, a, l, n;
            try {
                l = document.querySelector(".username-display").outerText;
                n = document.querySelectorAll("#dashboard-table > tbody > tr > td")
            } catch (i) {
                if (d()) {
                    f();
                    clearInterval(s)
                }
            }
            if (n) {
                e = n[1].outerText;
                t = n[4].outerText;
                r = n[3].outerText
            }
            if (!e) return;
            o = {
                visaDetails: e,
                userDetails: l,
                familyDetails: r,
                apntDetails: t
            };
            a = u(l);
            if (a) {
                chrome.storage.local.get(["userProfiles"], function (e) {
                    let t = {},
                        r = {
                            createdon: new Date
                        };
                    if (e.hasOwnProperty("userProfiles")) {
                        t = JSON.parse(e["userProfiles"])
                    }
                    if (!t.hasOwnProperty(a)) {
                        t[a] = {}
                    }
                    t[a] = {
                        ...o,
                        ...r
                    };
                    chrome.storage.local.set({
                        userProfiles: JSON.stringify(t)
                    }, function () {
                        clearInterval(s)
                    })
                })
            }
        }, 200)
    } catch (o) {
        console.log(o)
    }
} else if (e.indexOf("/en-us") > -1 && e.length <= 9) {
    try {
        let s = setInterval(() => {
            let e, t, r, o, a, l, n;
            try {
                l = document.querySelector(".username").outerText;
                n = document.querySelectorAll(".grid-row.grid-gap-3 li")
            } catch (i) {
                if (d()) {
                    f();
                    clearInterval(s)
                }
            }
            if (n) {
                e = m(n[0].outerText);
                e = e[e.length - 2];
                r = m(n[2].outerText, ":");
                r = r[r.length - 1];
                t = n[4] ? n[4].outerText : ""
            }
            if (!e) return;
            o = {
                visaDetails: e,
                userDetails: JSON.stringify(h()),
                familyDetails: r,
                apntDetails: t
            };
            a = u(l);
            if (a) {
                chrome.storage.local.get(["userProfiles"], function (e) {
                    let t = {},
                        r = {
                            createdon: new Date
                        };
                    if (e.hasOwnProperty("userProfiles")) {
                        t = JSON.parse(e["userProfiles"])
                    }
                    if (!t.hasOwnProperty(a)) {
                        t[a] = {}
                    }
                    t[a] = {
                        ...o,
                        ...r
                    };
                    chrome.storage.local.set({
                        userProfiles: JSON.stringify(t)
                    }, function () {
                        clearInterval(s)
                    })
                })
            }
        }, 200)
    } catch (o) {
        console.log(o)
    }
} else if (e === "/") {
    f()
}

function m(e, t = "\n") {
    let r = [];
    e.split(t).forEach(e => {
        e = e.trim();
        if (e) {
            r.push(e)
        }
    });
    return r
}

function n() {
    const e = document.querySelector("#post_select");
    return e[e.selectedIndex].text
}
async function l(e) {
    let o = {},
        a = n(),
        l = true;
    e.ScheduleDays?.forEach(e => {
        let t = new Date(e.Date),
            r;
        if (l) {
            p(t);
            l = false
        }
        r = t.toLocaleDateString("en-US", {
            month: "long",
            year: "numeric"
        });
        if (!o.hasOwnProperty(r)) {
            o[r] = {
                monthYear: r,
                dates: [],
                location: a
            }
        }
        o[r].dates.push(String(t.getDate()))
    });
    return Object.values(o)
}
async function i(e) {
    let t = [
        ["Time", "Available"]
    ];
    e.ScheduleEntries?.forEach(e => {
        t.push([e.Time, e.EntriesAvailable])
    });
    return t
}

function h() {
    const e = /"([^"]+@[^"]+)"/;
    const t = document.body.innerHTML.match(e);
    let r = "",
        o = document.querySelector(".username").outerText;
    if (t && t.length > 1) {
        r = t[1]
    }
    return {
        email: r,
        username: o,
        portal_id: u(o)
    }
}

function g(t, r, o, a, l) {
    html2canvas(document.body, {
        Allowtaint: false,
        Usecors: true,
        Scale: 2,
        Width: document.body.scrollWidth,
        Height: document.body.scrollHeight
    }).then(e => {
        chrome.runtime.sendMessage({
            resource: t,
            box: r,
            imgUri: e.toDataURL("image/png"),
            portal_id: u(l),
            slot_page: {
                slotDetails: o,
                appointmentTimes: a,
                slotPageUsername: l
            }
        })
    })
}

chrome.runtime.onMessage.addListener(msgObj => {
 //  console.log("----------------------------------");
 
   var selEl = document.getElementById("post_select");
   var dateValue= document.getElementById('datepicker').value;

   var fromdate= msgObj.fromdate;
   var todate=msgObj.todate;

   let datepickerdate=document.querySelector("#pagetitle").innerText.split(':');
   const month = ["Jan","Feb","Mar","Apr","May","June","July","Aug","Sept","Oct","Nov","Dec"];
   let currentdate= datepickerdate[0]+"-"+(month.indexOf(datepickerdate[1])+1)+"-"+datepickerdate[2];
  
   currentdate =new Date(currentdate).toLocaleDateString('fr-CA');
   var timeradio=document.getElementById('time_select_left');

   if((!(currentdate > fromdate && currentdate < todate) && timeradio.childElementCount!==0) && dateValue==='Loading...'){
    var event = new Event('change');
	selEl.dispatchEvent(event);
    console.log(" Refresh ");
}
   else if(dateValue==='Loading...'){
         console.log("No Refresh ");
   }
   else if(currentdate > fromdate && currentdate < todate){
    const buttoninterval= setInterval(() => {
        var subEle = document.getElementById('submitbtn');
        if(subEle.style.opacity='1'){
            clearInterval(buttoninterval);
            document.getElementById('submitbtn').click();
        }
        },1);
   }
   else if((!(currentdate > fromdate && currentdate < todate) && timeradio.childElementCount===0)
   || (!(currentdate > fromdate && currentdate < todate) && timeradio.childElementCount!==0)){
    console.log("Refreshing ");
    var event = new Event('change');
	selEl.dispatchEvent(event);
    console.log(currentdate);
    //if (currentdate > fromdate && currentdate < todate) {
      
        
      //} 
   }
   
   else {
    console.log("Not refreshing ");
   }
	


   //var conso= document.querySelector("#post_select").value;
   // console.log(selEl.value);
    //console.log(msgObj);
    
    //chrome.storage.local.set({ user_values: {"fromdate": msgObj.fromdate, "todate": msgObj.todate, "activeTab": msgObj.activetab , "consulate":conso, "tabid": msgObj.tabid } });
    //chrome.runtime.sendMessage({ message: 'changeconsulate' });

});
//chrome.runtime.sendMessage({ message: 'jamesmessage' });
addEventListener("vSCP", e => {
    if (e.detail.resource === "vD") {
        t(e.detail.data)
    } else if (e.detail.resource === "vSC") {
        r(e.detail.data)
    }
});
addEventListener("message", function(event) {
   // console.log("------------------===============================================================================")
   // console.log(event.data);
    // We only accept messages from this window to itself [i.e. not from any iframes]
    if (event.source != window)
      return;
  
    if (event.data.type && (event.data.type == "FROM_PAGE_TO_CONTENT_SCRIPT")) {        
      chrome.runtime.sendMessage(event.data); // broadcasts it to rest of extension, or could just broadcast event.data.payload...
    } // else ignore messages seemingly not sent to yourself
  }, false);



function t(o) {
    let a = u(document.querySelector(".username").outerText);
    chrome.storage.local.get(["userProfiles"], function (e) {
        let t = {},
            r = {
                createdon: new Date
            };
        if (e.hasOwnProperty("userProfiles")) {
            t = JSON.parse(e["userProfiles"])
        }
        if (!t.hasOwnProperty(a)) {
            t[a] = {}
        }
        t[a] = {
            ...t[a],
            ...{
                VisaClassID: o["Members"][0]["VisaClassID"],
                VisaClass: o["Members"][0]["VisaClassName"],
                userDetails: JSON.stringify(h())
            },
            ...r
        };
        chrome.storage.local.set({
            userProfiles: JSON.stringify(t)
        }, function () { })
    })
}
let s = [];
async function r(e) {
    let t = await i(e),
        r = await l(e);
    if (r.length > 1) {
        s = r
    } else {
        r = [{
            location: n()
        }]
    }
    if (t.length > 1) {
        y()
    }
    let o = c(document.querySelector("#page_form .col-sm-8")),
        a = document.querySelector(".username").outerText;
    g(resource = "/push/v5", o, t.length > 1 ? s : r, t, a)
}
async function p(e) {
    console.log('inside P');
    let t = new Date(e),
        r = t.getFullYear(),
        o = t.getMonth(),
        a = t.getDate();
        const month = ["Jan","Feb","Mar","Apr","May","June","July","Aug","Sept","Oct","Nov","Dec"];

        var tit=document.getElementById('pagetitle');
        tit.setAttribute("align","right");
        tit.setAttribute("style","margin-right: 68%");
        tit.innerHTML=r +":"+ month[o] +":"+a ;       

       /*  if( document.getElementById("dateText")!=null)
         document.getElementById("dateText").remove();
        var objTo = document.getElementById('main_container');
        var divtest = document.createElement("div");
        divtest.setAttribute("id","dateText")
       
        divtest.innerHTML = new Date(e);
        objTo.appendChild(divtest); */
    // const wait_until_element_appear = setInterval(() => {
    //     console.log('inside wait_until_element_appear');
    //     if (document.getElementsByClassName("form-control hasDatepicker").length !== 0) {
           
    //         clearInterval(wait_until_element_appear);
    //         let txt = document.getElementById('datepicker');
    //         let focusEvent = new Event('focus');
    //         //	let clickEvent = new Event('click');
    //         txt.dispatchEvent(focusEvent);
    //       //var dd= document.querySelector('#pagetitle').innerHTML;
    //      // console.log(dd);

    //     }
    // }, 1);


    const wait_until_year_appear = setInterval(() => {
        if (document.querySelector(".ui-datepicker-year") !== null) {
           // console.log('inside');
            clearInterval(wait_until_year_appear);
            var year_select = document.querySelector(".ui-datepicker-year");
            year_select.setAttribute('id', 'year');
            document.getElementById("year").value = r;
            var evt = document.createEvent("HTMLEvents");
            evt.initEvent("change", false, true);
            year_select.dispatchEvent(evt);

        }
    }, 1);

    const wait_until_month_appear = setInterval(() => {
        if (document.querySelector(".ui-datepicker-month") !== null) {
            //console.log('inside');
            clearInterval(wait_until_month_appear);
            var month_select = document.querySelector(".ui-datepicker-month");
            month_select.setAttribute('id', 'month');
            document.getElementById("month").value = o;
            var evt = document.createEvent("HTMLEvents");
            evt.initEvent("change", false, true);
            month_select.dispatchEvent(evt);
        

        }
    }, 1);

    const wait_until_click_appear = setInterval(() => {
        if (document.querySelector(`.ui-datepicker-calendar a[data-date="${a}"]`) !== null) {
            clearInterval(wait_until_click_appear);
            document.querySelector(`.ui-datepicker-calendar a[data-date="${a}"]`).click()

        }
    }, 1);


    // document.querySelector("#datepicker.form-control").focus();




   

    /*  let l = document.querySelector(".ui-datepicker-year").value,
         n = document.querySelector(".ui-datepicker-month").value;
     let i = r - l,
         s = o - n;
     let c = i * 12 + s;
     for (let e = 0; e < c; e++) {
         document.querySelector(`.ui-datepicker-next`).click()
     } */
}
async function y(e) {
    cok=document.querySelectorAll('input[type=radio]');
    let d = Math.floor(cok.length/2);
    cok[d].click();
   // document.querySelector('input[type="radio"]').click()
}

let button = document.createElement("button");
button.setAttribute("id", "selflocation");
button.setAttribute("class", "btn-atlas btn-atlas-submit pull-top");
function changeConsolate_1(consolate) {
    var selEl = document.getElementById("post_select");
       var event = new Event('change');
      
	selEl.value = consolate;
       selEl.dispatchEvent(event);
       
   }
   var screenName=document.querySelector("#page_form > div:nth-child(1) > div.col-sm-8.atlas_section > div:nth-child(2) > div > div:nth-child(1) > div > label").innerHTML;
   button.addEventListener("click", changeConsolate_1.bind(this, screenName==='Consular Posts'?'716af614-b0db-ec11-a7b4-001dd80234f6':'486bf614-b0db-ec11-a7b4-001dd80234f6'));
   var parentele=document.getElementById("page_form");
   parentele.insertBefore(button, parentele.firstChild);
   document.getElementById('selflocation').innerHTML = "Mumbai";

   var sub=document.getElementById('submitbtn');
   sub.setAttribute("class","btn-atlas btn-atlas-submit pull-top")
   parentele.insertBefore(sub, parentele.firstChild);


let buttondelhi = document.createElement("button");
buttondelhi.setAttribute("id", "delhibutton");
buttondelhi.setAttribute("class", "btn-atlas btn-atlas-submit pull-top");
buttondelhi.addEventListener("click", changeConsolate_1.bind(this, screenName==='Consular Posts'?'e66af614-b0db-ec11-a7b4-001dd80234f6':'486bf614-b0db-ec11-a7b4-001dd80234f6'));
   
var parentele=document.getElementById("page_form");
parentele.insertBefore(buttondelhi, parentele.firstChild);
document.getElementById('delhibutton').innerHTML = "Delhi";

